const express = require('express');
const router = express.Router();
const Slot = require('../models/Slot');
const ParkingHistory = require('../models/ParkingHistory');

// Add a slot
router.post('/slots', async (req, res) => {
    try {
        const slot = new Slot({ name: req.body.name });
        await slot.save();
        res.status(201).json(slot);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Get all slots
router.get('/slots', async (req, res) => {
    const slots = await Slot.find();
    res.json(slots);
});

// Get all parking history
router.get('/history', async (req, res) => {
    const history = await ParkingHistory.find().sort({ time: -1 });
    res.json(history);
});

// Search history by customer
router.get('/history/search', async (req, res) => {
    const { customerName } = req.query;
    const results = await ParkingHistory.find({ customerName: { $regex: customerName, $options: 'i' } });
    res.json(results);
});

// Add new history record (simulate parking)
router.post('/history', async (req, res) => {
    try {
        const record = new ParkingHistory(req.body);
        await record.save();
        res.status(201).json(record);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

module.exports = router;
