router.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await user.findOne({ username });
        if (!user) {
            return res.status(400).json({ error: 'Invalid username' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ error: 'Invalid password' });
        }

        // Optional: create session or token here
        res.json({ message: 'Login successful', userId: user._id });
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
});
