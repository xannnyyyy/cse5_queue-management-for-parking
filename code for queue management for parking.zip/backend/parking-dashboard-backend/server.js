console.log("🧪 Test message at top of file");
console.log("🔥 server.js file is running...");

const express = require('express');
const mongoose = require('mongoose');
const Razorpay = require('razorpay');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

// ✅ Routes
const apiRoutes = require('./routes/api');
const userRoutes = require('./routes/userRoutes');

const app = express();

// 🛡️ Middleware Setup
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public'))); // Serve frontend files (payment.html, etc.)

// 💳 Razorpay Setup (Test Keys from Dashboard)
const razorpay = new Razorpay({
  key_id: "rzp_test_YiJT4H74s6kGcK",       // ✅ Your test key
  key_secret: "ziDcCy4YE8epp6S9VIPMF"      // ✅ Your test secret
});

// 🔌 MongoDB Connection
mongoose.connect('mongodb://localhost:27017/parkingDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("✅ MongoDB connected"))
.catch(err => console.log("❌ MongoDB error:", err));

// 📦 Main API Routes
app.use('/api', apiRoutes);           // Login, Register
app.use('/api/user', userRoutes);     // Profile page routes

// 💰 Razorpay Payment Route
app.post('/api/pay', async (req, res) => {
  const { amount } = req.body;

  const options = {
    amount: amount,                  // Make sure this is in paise (₹50 = 5000)
    currency: "INR",
    receipt: `receipt_order_${Date.now()}`
  };

  try {
    const order = await razorpay.orders.create(options);
    res.status(200).json(order);     // Send order info to frontend
  } catch (err) {
    console.error("❌ Razorpay Error:", err);
    res.status(500).send("Payment initiation failed");
  }
});

// 📄 Serve Profile Page
app.get('/profile', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'profile.html'));
});

// 📄 Serve Payment Confirmation Page
app.get('/payment-confirmation', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'payment-confirmation.html'));
});

// 🚀 Start the Server
const PORT = 5501;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
