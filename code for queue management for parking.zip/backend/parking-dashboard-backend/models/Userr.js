const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  carNumber: { type: String, required: true },
  parkingSlot: { type: String },
  queuePosition: { type: Number }
});

module.exports = mongoose.model('Userr', userSchema);
